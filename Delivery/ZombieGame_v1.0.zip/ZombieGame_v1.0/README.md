README

# ZombieGame

Project for IDI subject.

This project has been done by Aitor Simona, Andr�s Saladrigas and Adri�n Font students of CITM - UPC (Barcelona, Spain). 

* [Github repository](https://github.com/Mad-Engine/ZombieGame)  


 ## Installation instructions 

Download the Zip file and extract it. Open the folder and double click on the executable (.exe) 

_IMPORTANT: do not modify, change or add any folder or file, or else the game may not work correctly._ 

## Controls Player controls: 

- A,W,S,D: Move

- LEFT CLICK: shoot(click on enemies to kill them).


## How to play 

The goal of the game is to survive as much time as possible.

## Team members 

_Adrian Font Romero Github account:_ 
* [Github account](https://github.com/AdrianFR99) 

_Andr�s Ricardo Saladrigas P�rez Github account:_ 
* [Github account](https://github.com/TheArzhel) 

_Aitor Simona Bouzas account:_
* [Github account](https://github.com/AitorSimona) 


## Report
The exacutable creates an xml file which includes the variables 
which can be used for data analysis playtesting and statistics goals

## Tools used 
* Microsoft Visual Studio 2017 
* Language: C++ * Graphics and audio: SDL 2.0.4 
* Tiled
* Code repository: GitHub 
* Others: Adobe Photoshop and Audacity 